<script setup>

</script>

<template>
    <div class="card">
        <h3>나에게 맞는 상품 추천</h3>
        <div>
            <h5><strong>상품 정보</strong></h5>
            <p>WON플러스예금</p>
            <p>우리은행</p>
            <h5><strong>옵션 정보</strong></h5>
            <p>최고 우대 금리: 4.02</p>
            <p>저축기간: 6</p>
        </div>
    </div>
</template>

<style scoped>

.card {
    width: 700px;
    padding: 20px;
    border: 5px gray solid;
    border-radius: 5px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    align-items: flex;
}

</style>
